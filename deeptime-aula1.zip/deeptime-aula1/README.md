# Curso de séries temporais com o Keras
Previsão de séries temporais usando o Keras
